livery = {
	{"f15nose", 0 ,"f15_noseF",false};
	{"f15nose", 3 ,"f15_decol_bx_akg",false};
	{"f15bottom", 0 ,"f15_bottomF",false};
	{"f15bottom", 3 ,"f15_decol_bx_akg",false};
	{"f15centr", 0 ,"f15_centrF",false};
	{"f15wingl", 0 ,"f15_wrL",false};
	{"f15wingl", 3 ,"f15_decol_bx_akg",false};
	{"f15wingr", 0 ,"f15_wrF",false};
	{"f15stab", 0 ,"f15_stabF",false};
	{"f15stab", 3 ,"f15_decol_bx_akg",false};
	{"f15numbers", 0 ,"f15_numbers",true};
	{"pilot_F15_patch", 0 ,"pilot_F15_patch_65A_sqdn",true};
	{"pilot_F15_00_body", 0 ,"pilot_f15_00_a",true};
	{"f15PTB", 0 ,"f15_PTB",false};
}

countries = {"USA"}